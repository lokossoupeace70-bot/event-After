document.addEventListener('DOMContentLoaded', () => {

    /* ==========================================================================
       1. HEADER STYLING ON SCROLL
       ========================================================================== */
    const header = document.querySelector('.main-header');
    const updateHeader = () => {
        if (window.scrollY > 50) header.classList.add('scrolled');
        else header.classList.remove('scrolled');
    };
    updateHeader();
    window.addEventListener('scroll', updateHeader, { passive: true });

    /* ==========================================================================
       2. MOBILE MENU
       ========================================================================== */
    const menuBtn = document.querySelector('.mobile-menu-btn');
    const navOverlay = document.querySelector('.mobile-nav-overlay');
    const navLinks = document.querySelectorAll('.mobile-nav a');

    function toggleMenu() {
        const isOpen = menuBtn.classList.toggle('active');
        navOverlay.classList.toggle('active');
        document.body.classList.toggle('no-scroll');
        menuBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    }
    if (menuBtn) menuBtn.addEventListener('click', toggleMenu);
    navLinks.forEach(link => link.addEventListener('click', () => {
        if (navOverlay.classList.contains('active')) toggleMenu();
    }));

    /* ==========================================================================
       3. SCROLL REVEAL (IntersectionObserver)
       ========================================================================== */
    const animatedElements = document.querySelectorAll('.fade-in, .fade-in-up, .fade-in-left, .fade-in-right');
    const revealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('appear');
                observer.unobserve(entry.target);
            }
        });
    }, { root: null, rootMargin: '0px', threshold: 0.15 });
    animatedElements.forEach(el => revealObserver.observe(el));

    /* ==========================================================================
       4. HERO SLIDESHOW (JS-controlled, clickable indicators)
       ========================================================================== */
    const slides = document.querySelectorAll('.hero-slideshow .slide');
    const indicators = document.querySelectorAll('.indicator');
    let currentSlide = 0;
    let slideTimer = null;

    function goToSlide(index) {
        slides.forEach(s => s.classList.remove('active'));
        indicators.forEach(i => i.classList.remove('active'));
        slides[index].classList.add('active');
        if (indicators[index]) indicators[index].classList.add('active');
        currentSlide = index;
    }

    function nextSlide() {
        goToSlide((currentSlide + 1) % slides.length);
    }

    function startSlideshow() {
        clearInterval(slideTimer);
        slideTimer = setInterval(nextSlide, 6000);
    }

    if (slides.length) {
        goToSlide(0);
        startSlideshow();
        indicators.forEach((btn, i) => {
            btn.addEventListener('click', () => {
                goToSlide(i);
                startSlideshow();
            });
        });
    }

    /* ==========================================================================
       5. GSAP SCROLL-TRIGGERED "PUMP" ON SERVICE NUMBERS
       ========================================================================== */
    const timelineNumbers = document.querySelectorAll('.timeline-number');

    if (window.gsap && window.ScrollTrigger) {
        gsap.registerPlugin(ScrollTrigger);
        timelineNumbers.forEach((num) => {
            ScrollTrigger.create({
                trigger: num,
                start: 'top 80%',
                onEnter: () => {
                    gsap.fromTo(num,
                        { scale: 1 },
                        { scale: 1.35, duration: 0.3, ease: 'power2.out', yoyo: true, repeat: 1 }
                    );
                    num.classList.add('pulse');
                }
            });
        });
    } else {
        // Graceful degradation: CSS-only pulse via IntersectionObserver
        const numObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('pulse');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.6 });
        timelineNumbers.forEach(num => numObserver.observe(num));
    }

    /* ==========================================================================
       6. GALLERY — FILTERS
       ========================================================================== */
    const filterChips = document.querySelectorAll('.filter-chip');
    const galleryItems = document.querySelectorAll('.gallery-item');

    filterChips.forEach(chip => {
        chip.addEventListener('click', () => {
            filterChips.forEach(c => c.classList.remove('active'));
            chip.classList.add('active');
            const filter = chip.dataset.filter;
            galleryItems.forEach(item => {
                const match = filter === 'all' || item.dataset.category === filter;
                item.style.display = match ? '' : 'none';
            });
        });
    });

    /* ==========================================================================
       7. GALLERY — INERTIAL DRAG CAROUSEL
       ========================================================================== */
    const viewport = document.getElementById('carousel-viewport');
    const track = document.getElementById('carousel-track');
    const prevBtn = document.getElementById('carousel-prev');
    const nextBtn = document.getElementById('carousel-next');

    if (viewport && track) {
        let posX = 0;          // current translateX
        let velocity = 0;      // px per frame
        let isDragging = false;
        let startX = 0;
        let lastX = 0;
        let lastTime = 0;
        let rafId = null;

        function getMaxScroll() {
            return Math.max(0, track.scrollWidth - viewport.clientWidth);
        }

        function clamp(val, min, max) {
            return Math.min(Math.max(val, min), max);
        }

        function applyTransform() {
            track.style.transform = `translateX(${-posX}px)`;
        }

        function settleBounds() {
            const max = getMaxScroll();
            if (posX < 0) posX = 0;
            if (posX > max) posX = max;
            applyTransform();
        }

        function inertiaLoop() {
            if (Math.abs(velocity) > 0.5) {
                posX += velocity;
                velocity *= 0.94; // friction

                const max = getMaxScroll();
                // soft bounce at edges
                if (posX < 0) { posX = 0; velocity = 0; }
                if (posX > max) { posX = max; velocity = 0; }

                applyTransform();
                rafId = requestAnimationFrame(inertiaLoop);
            } else {
                cancelAnimationFrame(rafId);
            }
        }

        function pointerDown(x) {
            isDragging = true;
            cancelAnimationFrame(rafId);
            startX = x;
            lastX = x;
            lastTime = performance.now();
            velocity = 0;
            viewport.classList.add('dragging');
        }

        function pointerMove(x) {
            if (!isDragging) return;
            const now = performance.now();
            const dx = x - lastX;
            posX -= dx;
            posX = clamp(posX, -80, getMaxScroll() + 80); // slight rubber-band
            applyTransform();

            const dt = Math.max(now - lastTime, 1);
            velocity = -(dx / dt) * 16; // scale to ~per-frame px at 60fps
            lastX = x;
            lastTime = now;
        }

        function pointerUp() {
            if (!isDragging) return;
            isDragging = false;
            viewport.classList.remove('dragging');
            settleBounds();
            rafId = requestAnimationFrame(inertiaLoop);
        }

        // Mouse events
        viewport.addEventListener('mousedown', (e) => { pointerDown(e.clientX); e.preventDefault(); });
        window.addEventListener('mousemove', (e) => pointerMove(e.clientX));
        window.addEventListener('mouseup', pointerUp);

        // Touch events
        viewport.addEventListener('touchstart', (e) => pointerDown(e.touches[0].clientX), { passive: true });
        viewport.addEventListener('touchmove', (e) => pointerMove(e.touches[0].clientX), { passive: true });
        viewport.addEventListener('touchend', pointerUp);

        // Prevent native image drag ghosting
        track.querySelectorAll('img').forEach(img => img.addEventListener('dragstart', e => e.preventDefault()));

        // Button controls (jump by one card width)
        function cardStep() {
            const card = track.querySelector('.gallery-item');
            if (!card) return 300;
            const style = getComputedStyle(track);
            const gap = parseFloat(style.gap) || 20;
            return card.getBoundingClientRect().width + gap;
        }

        if (prevBtn) prevBtn.addEventListener('click', () => {
            cancelAnimationFrame(rafId);
            posX = clamp(posX - cardStep(), 0, getMaxScroll());
            track.style.transition = 'transform 0.5s cubic-bezier(0.25,0.46,0.45,0.94)';
            applyTransform();
            setTimeout(() => track.style.transition = '', 500);
        });
        if (nextBtn) nextBtn.addEventListener('click', () => {
            cancelAnimationFrame(rafId);
            posX = clamp(posX + cardStep(), 0, getMaxScroll());
            track.style.transition = 'transform 0.5s cubic-bezier(0.25,0.46,0.45,0.94)';
            applyTransform();
            setTimeout(() => track.style.transition = '', 500);
        });

        window.addEventListener('resize', settleBounds);
    }

    /* ==========================================================================
       8. GALLERY LIGHTBOX
       ========================================================================== */
    const lightbox = document.getElementById('gallery-lightbox');
    if (lightbox) {
        const lightboxImg = lightbox.querySelector('.lightbox-img');
        const lightboxTitle = lightbox.querySelector('.lightbox-title');
        const lightboxCategory = lightbox.querySelector('.lightbox-category');
        const closeBtn = lightbox.querySelector('.lightbox-close');
        const lbPrevBtn = lightbox.querySelector('.lightbox-prev');
        const lbNextBtn = lightbox.querySelector('.lightbox-next');

        let currentIndex = 0;
        const imagesData = [];

        galleryItems.forEach((item, index) => {
            const h4 = item.querySelector('h4');
            const cat = item.querySelector('.gallery-category');
            imagesData.push({
                src: item.getAttribute('data-src') || item.querySelector('img').src,
                title: h4 ? h4.textContent : '',
                category: cat ? cat.textContent : ''
            });
            item.addEventListener('click', () => {
                if (!isDraggedRecently()) openLightbox(index);
            });
        });

        // Avoid opening lightbox right after a drag gesture
        let lastDragEnd = 0;
        if (viewport) {
            viewport.addEventListener('mouseup', () => { lastDragEnd = Date.now(); });
            viewport.addEventListener('touchend', () => { lastDragEnd = Date.now(); });
        }
        function isDraggedRecently() { return Date.now() - lastDragEnd < 150; }

        function openLightbox(index) {
            currentIndex = index;
            updateLightboxContent();
            lightbox.classList.add('active');
            lightbox.setAttribute('aria-hidden', 'false');
            document.body.classList.add('no-scroll');
        }
        function closeLightbox() {
            lightbox.classList.remove('active');
            lightbox.setAttribute('aria-hidden', 'true');
            document.body.classList.remove('no-scroll');
        }
        function updateLightboxContent() {
            const d = imagesData[currentIndex];
            lightboxImg.src = d.src;
            lightboxImg.alt = d.title;
            lightboxTitle.textContent = d.title;
            lightboxCategory.textContent = d.category;
        }
        function showPrev() { currentIndex = (currentIndex - 1 + imagesData.length) % imagesData.length; updateLightboxContent(); }
        function showNext() { currentIndex = (currentIndex + 1) % imagesData.length; updateLightboxContent(); }

        if (closeBtn) closeBtn.addEventListener('click', closeLightbox);
        if (lbPrevBtn) lbPrevBtn.addEventListener('click', showPrev);
        if (lbNextBtn) lbNextBtn.addEventListener('click', showNext);
        lightbox.addEventListener('click', (e) => { if (e.target === lightbox) closeLightbox(); });
        document.addEventListener('keydown', (e) => {
            if (!lightbox.classList.contains('active')) return;
            if (e.key === 'Escape') closeLightbox();
            if (e.key === 'ArrowLeft') showPrev();
            if (e.key === 'ArrowRight') showNext();
        });
    }

    /* ==========================================================================
       9. TESTIMONIAL STAR RATINGS (partial fill)
       ========================================================================== */
    document.querySelectorAll('.rating-stars').forEach(el => {
        const rating = parseFloat(el.dataset.rating || '5');
        const pct = Math.max(0, Math.min(100, (rating / 5) * 100));
        const fill = el.querySelector('.stars-fill');
        if (fill) fill.style.width = pct + '%';
    });

    /* ==========================================================================
       10. MARQUEE — duplicate track content for seamless infinite loop
       ========================================================================== */
    const marqueeTrack = document.getElementById('marquee-track');
    if (marqueeTrack) {
        const original = Array.from(marqueeTrack.children);
        original.forEach(card => {
            const clone = card.cloneNode(true);
            clone.setAttribute('aria-hidden', 'true');
            marqueeTrack.appendChild(clone);
        });
    }

    /* ==========================================================================
       11. PARTNERS WHEEL — position items around the circles + heroic reveal
       ========================================================================== */
    function layoutWheel(ringSelector, radiusRatio) {
        const ring = document.querySelector(ringSelector);
        if (!ring) return;
        const items = ring.querySelectorAll('.wheel-item');
        const stage = document.getElementById('wheel-stage');
        if (!stage) return;
        const size = stage.getBoundingClientRect().width;
        const radius = (size * radiusRatio) / 2;
        items.forEach(item => {
            const angle = item.dataset.angle || 0;
            item.style.setProperty('--angle', angle + 'deg');
            item.style.setProperty('--radius', radius + 'px');
        });
    }

    function layoutAllWheels() {
        layoutWheel('#ring-outer', 0.98);
        layoutWheel('#ring-inner', 0.62);
    }
    layoutAllWheels();
    window.addEventListener('resize', layoutAllWheels);

    const partnersHeroic = document.getElementById('partners-heroic');
    if (partnersHeroic) {
        const heroicObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('appear');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.3 });
        heroicObserver.observe(partnersHeroic);
    }

    /* ==========================================================================
       12. BUDGET ESTIMATOR
       ========================================================================== */
    const guestsRange = document.getElementById('range-guests');
    const guestsValue = document.getElementById('guests-value');
    const formulaOptions = document.getElementById('formula-options');
    const checksWrap = document.getElementById('estimator-checks');
    const totalEl = document.getElementById('estimator-total');
    const breakdownEl = document.getElementById('estimator-breakdown');

    if (guestsRange && formulaOptions && totalEl) {
        let selectedFormula = formulaOptions.querySelector('.formula-chip.active');

        function formatEUR(n) {
            return n.toLocaleString('fr-FR', { maximumFractionDigits: 0 }) + ' €';
        }

        function computeEstimate() {
            const guests = parseInt(guestsRange.value, 10);
            guestsValue.textContent = guests;

            const pricePerGuest = parseInt(selectedFormula.dataset.price, 10);
            const baseTotal = guests * pricePerGuest;

            let optionsTotal = 0;
            const optionLines = [];
            checksWrap.querySelectorAll('input[type="checkbox"]').forEach(cb => {
                if (cb.checked) {
                    const price = parseInt(cb.dataset.price, 10);
                    optionsTotal += price;
                    const label = cb.closest('.check-row').textContent.trim().split('+')[0].trim();
                    optionLines.push({ label, price });
                }
            });

            const grandTotal = baseTotal + optionsTotal;

            totalEl.textContent = formatEUR(grandTotal);

            breakdownEl.innerHTML = `
                <div><span>${guests} invités × formule ${selectedFormula.dataset.formula}</span><span>${formatEUR(baseTotal)}</span></div>
                ${optionLines.map(o => `<div><span>${o.label}</span><span>+${formatEUR(o.price)}</span></div>`).join('')}
            `;
        }

        guestsRange.addEventListener('input', computeEstimate);
        formulaOptions.querySelectorAll('.formula-chip').forEach(chip => {
            chip.addEventListener('click', () => {
                formulaOptions.querySelectorAll('.formula-chip').forEach(c => c.classList.remove('active'));
                chip.classList.add('active');
                selectedFormula = chip;
                computeEstimate();
            });
        });
        checksWrap.querySelectorAll('input[type="checkbox"]').forEach(cb => {
            cb.addEventListener('change', computeEstimate);
        });

        computeEstimate();
    }

    /* ==========================================================================
       13. APPOINTMENT SCHEDULER
       ========================================================================== */
    const datesWrap = document.getElementById('scheduler-dates');
    const slotsWrap = document.getElementById('scheduler-slots');
    const appointmentForm = document.getElementById('appointment-form');
    const appointmentFeedback = document.getElementById('appointment-feedback');

    if (datesWrap && slotsWrap) {
        const dayNames = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];
        const today = new Date();
        const dates = [];
        for (let i = 1; i <= 10; i++) {
            const d = new Date(today);
            d.setDate(today.getDate() + i);
            if (d.getDay() === 0) continue; // skip Sundays
            dates.push(d);
            if (dates.length >= 7) break;
        }

        let selectedDateIndex = 0;
        let selectedSlot = null;

        const allSlots = ['09:00', '10:30', '12:00', '14:00', '15:30', '17:00'];

        function renderDates() {
            datesWrap.innerHTML = '';
            dates.forEach((d, i) => {
                const chip = document.createElement('button');
                chip.type = 'button';
                chip.className = 'date-chip' + (i === selectedDateIndex ? ' active' : '');
                chip.innerHTML = `<span class="date-day">${dayNames[d.getDay()]}</span><span class="date-num">${d.getDate()}</span>`;
                chip.addEventListener('click', () => {
                    selectedDateIndex = i;
                    selectedSlot = null;
                    renderDates();
                    renderSlots();
                });
                datesWrap.appendChild(chip);
            });
        }

        function renderSlots() {
            slotsWrap.innerHTML = '';
            // Deterministic pseudo-availability based on date index, so it feels real but stays stable
            const seed = selectedDateIndex;
            allSlots.forEach((slot, i) => {
                const unavailable = (seed + i) % 4 === 0;
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'slot-chip' + (slot === selectedSlot ? ' active' : '');
                btn.textContent = slot;
                if (unavailable) {
                    btn.disabled = true;
                } else {
                    btn.addEventListener('click', () => {
                        selectedSlot = slot;
                        renderSlots();
                    });
                }
                slotsWrap.appendChild(btn);
            });
        }

        renderDates();
        renderSlots();

        if (appointmentForm) {
            appointmentForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const name = document.getElementById('appt-name').value;
                const email = document.getElementById('appt-email').value;

                if (!name || !email) {
                    showFeedback(appointmentFeedback, 'Veuillez renseigner votre nom et votre e-mail.', 'error');
                    return;
                }
                if (!selectedSlot) {
                    showFeedback(appointmentFeedback, 'Veuillez choisir un créneau horaire disponible.', 'error');
                    return;
                }

                const chosenDate = dates[selectedDateIndex];
                const dateLabel = chosenDate.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' });

                showFeedback(appointmentFeedback, `Merci ${name} ! Rendez-vous confirmé le ${dateLabel} à ${selectedSlot}. Un e-mail de confirmation vous a été envoyé.`, 'success');
                appointmentForm.reset();
                selectedSlot = null;
                renderSlots();
            });
        }
    }

    /* ==========================================================================
       14. FORM FEEDBACK HELPER
       ========================================================================== */
    function showFeedback(el, text, type) {
        if (!el) return;
        el.textContent = text;
        el.className = 'form-feedback-message';
        el.classList.add(type);
        el.style.display = 'block';
        setTimeout(() => { el.style.display = 'none'; }, 8000);
    }

    /* ==========================================================================
       15. MAIN CONTACT FORM
       ========================================================================== */
    const contactForm = document.getElementById('wedding-contact-form');
    const formFeedback = document.getElementById('form-feedback');

    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const name = document.getElementById('form-name').value;
            const email = document.getElementById('form-email').value;
            const message = document.getElementById('form-message').value;
            const type = document.getElementById('form-type').value;

            if (!name || !email || !message || !type) {
                showFeedback(formFeedback, 'Veuillez remplir tous les champs obligatoires (*).', 'error');
                return;
            }

            const submitBtn = contactForm.querySelector('.btn-submit');
            const submitBtnText = submitBtn.querySelector('span');
            const originalText = submitBtnText.textContent;
            submitBtn.disabled = true;
            submitBtnText.textContent = 'Envoi en cours...';

            setTimeout(() => {
                showFeedback(formFeedback, `Merci ${name} ! Votre demande a bien été envoyée. Nous vous recontacterons sous 24h.`, 'success');
                contactForm.reset();
                submitBtn.disabled = false;
                submitBtnText.textContent = originalText;
            }, 1200);
        });
    }

    /* ==========================================================================
       16. PARTNERS LEAD FORM
       ========================================================================== */
    const leadForm = document.getElementById('partners-lead-form');
    const leadFeedback = document.getElementById('lead-form-feedback');

    if (leadForm) {
        leadForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const name = document.getElementById('lead-name').value;
            const email = document.getElementById('lead-email').value;

            if (!name || !email) {
                showFeedback(leadFeedback, 'Merci de renseigner votre nom et votre e-mail.', 'error');
                return;
            }

            showFeedback(leadFeedback, `Merci ${name} ! Votre catalogue partenaires arrivera à ${email} sous 48h.`, 'success');
            leadForm.reset();
        });
    }

    /* ==========================================================================
       17. AI CHATBOT WIDGET (rule-based FAQ + theme suggestions)
       ========================================================================== */
    const chatbotDock = document.getElementById('chatbot-dock');
    const chatbotToggle = document.getElementById('chatbot-toggle');
    const chatbotMessages = document.getElementById('chatbot-messages');
    const chatbotForm = document.getElementById('chatbot-form');
    const chatbotInput = document.getElementById('chatbot-input');
    const chatSuggestions = document.getElementById('chat-suggestions');

    const knowledgeBase = {
        delais: "Nous recommandons de nous contacter 8 à 12 mois avant votre date, surtout pour les mariages fusion qui demandent une double coordination. Certaines dates prisées se réservent jusqu'à 18 mois à l'avance.",
        budget: "Nos formules démarrent à 180€/invité (Essentielle) et vont jusqu'à 520€/invité (Prestige). Utilisez notre simulateur juste au-dessus pour une estimation personnalisée en temps réel.",
        theme: "Pour un mariage fusion, j'aime beaucoup l'idée d'une cérémonie civile en blanc le matin, suivie d'une cérémonie de dotation en tenues Kente l'après-midi, et d'une soirée de gala aux couleurs terracotta et or le soir. Voulez-vous que je détaille ce concept ?",
        fusion: "Un mariage fusion combine les rites de vos deux cultures dans une même célébration : cérémonie traditionnelle (dot, bénédictions) et cérémonie occidentale (civile ou religieuse), avec une scénographie qui fait dialoguer les deux univers plutôt que de les juxtaposer.",
        default: "Merci pour votre message ! Un membre de notre équipe vous répondra personnellement. En attendant, vous pouvez consulter nos formules dans le simulateur de budget ou réserver directement une consultation."
    };

    function addBubble(text, sender) {
        const bubble = document.createElement('div');
        bubble.className = `chat-bubble ${sender}`;
        bubble.textContent = text;
        chatbotMessages.appendChild(bubble);
        chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
    }

    function botReply(topicKey, userText) {
        addBubble(userText, 'user');
        setTimeout(() => {
            const reply = knowledgeBase[topicKey] || knowledgeBase.default;
            addBubble(reply, 'bot');
        }, 500);
    }

    if (chatbotToggle && chatbotDock) {
        chatbotToggle.addEventListener('click', () => {
            chatbotDock.classList.toggle('open');
            if (chatbotDock.classList.contains('open')) {
                chatbotInput.focus();
            }
        });
    }

    if (chatSuggestions) {
        chatSuggestions.querySelectorAll('.chat-suggestion-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const key = btn.dataset.q;
                botReply(key, btn.textContent);
            });
        });
    }

    if (chatbotForm) {
        chatbotForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const text = chatbotInput.value.trim();
            if (!text) return;

            const lower = text.toLowerCase();
            let matchedKey = 'default';
            if (/(délai|delai|quand|réserv)/.test(lower)) matchedKey = 'delais';
            else if (/(budget|prix|coût|cout|tarif)/.test(lower)) matchedKey = 'budget';
            else if (/(thème|theme|idée|inspiration)/.test(lower)) matchedKey = 'theme';
            else if (/(fusion|deux cultures|traditionnel)/.test(lower)) matchedKey = 'fusion';

            botReply(matchedKey, text);
            chatbotInput.value = '';
        });
    }

});
